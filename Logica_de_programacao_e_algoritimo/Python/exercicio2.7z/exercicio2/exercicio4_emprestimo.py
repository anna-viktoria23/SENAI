#-*- coding: UTF-8 -*-

print("o programa é para emprestimo")

valor_casa= float(input("me de o valor da casa"))
