#-*- coding: UTF-8 -*-

print("Digite o valor do seu salário e eu lhe direi se ele aumentou 10 ou 15 porcento")

sal= float(input("Digite o valor do seu salário: "))
if sal < 1250.00:
    print("ele aumentou 15 porcento, e agora seu valor é de: " (sal * 15)/100)
else: sal > 1250.00
print("ele aumentou dez porcento, e agora seu valor é de: " (sal * 10)/ 100)
