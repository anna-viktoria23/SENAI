x = 7

if x % 2 == 0:

    print("Par")

else:


    print("Ímpar")
