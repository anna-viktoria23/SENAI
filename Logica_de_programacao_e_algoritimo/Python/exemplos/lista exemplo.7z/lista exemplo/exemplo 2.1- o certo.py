# -*- coding: UTF-8 -*-

L = [1, 2, 3, 4, 5]

V = L[:]

V[0] = 6

print (L)

print (V)
