# -*- coding: UTF-8 -*-

x = 1
while x <= 3:
    print(x)
    x = x + 1
