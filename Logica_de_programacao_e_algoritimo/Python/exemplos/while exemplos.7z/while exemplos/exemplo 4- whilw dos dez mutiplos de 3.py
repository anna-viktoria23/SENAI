

x = 1

while x <= 50:
    if x % 3 == 0:
        print(x)
    x = x + 1
