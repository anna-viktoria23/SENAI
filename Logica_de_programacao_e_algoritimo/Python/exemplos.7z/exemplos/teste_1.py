#-*- coding: UTF-8 -*-
#print ("oi")
print("esse programa fara o calculo da soma de dois valores INTEIROS!")
num1= int(input("digite o primeiro valor: "))
num2= int(input("digite o segundo valor: "))
soma= num1 + num2
print("o resultado da soma é: ", soma)
