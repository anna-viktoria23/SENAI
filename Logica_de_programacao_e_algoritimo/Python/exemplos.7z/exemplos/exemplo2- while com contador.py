
# -*- coding: UTF-8 -*-

fim = int(input("Digite o último número a imprimir: "))
cont = 1

while cont <= fim:
    print(cont)
    cont = cont + 1
