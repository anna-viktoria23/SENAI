# -*- coding: UTF-8 -*-

n = int(input("Tabuada de: "))
x = 0

while x <= 10:
    #print (n, "x", x, "=", (n * x))
    #print(f'(n) * (x) = (n*x)')
    x = x + 1
