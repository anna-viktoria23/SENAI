#-*- coding: UTF-8 -*-

print("oi usuário! vou fazer a média pra você de três salários")
salario1 = float(input("Digite o primeiro salário: "))
salario2= float(input("Digite o segundo salário: "))
salario3= float(input("Digite o terceiro salário: "))

media_salarios= (salario1 + salario2 + salario3)/3

print("O resultado da média é: ",media_salarios)
