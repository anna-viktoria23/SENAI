#-*- coding: UTF-8 -*-

print("lhe darei a temperatuea em F")

cel= float(input("Me de a temperatura em celcius"))
cont= 9 / 5 * cel + 31

print("a temperatura em F é de: ",cont)
