
#-*- coding: UTF-8 -*-

print("me diga qual sua distancia  a percorrer e a velocidade média da viagem que eu lhe direi seu tempo de viagem")

dist= int(input("Digite sua distancia percorrida: "))
vel_m= int(input("Digite sua velocidade media: "))

tempo= dist/vel_m
print("o tempo de viagem é de: ",tempo)
