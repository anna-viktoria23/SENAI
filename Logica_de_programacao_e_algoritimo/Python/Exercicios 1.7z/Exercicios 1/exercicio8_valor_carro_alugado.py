print("vamos calcular o valor de um carro")

#1 dia R$60/ cada km R$0.15

distancia_km = float(input("Digite a distancia percorrida: "))

dias= int(input("Digite o total de dias: "))

valor_final= dias * 60 + distancia_km * 0.15


