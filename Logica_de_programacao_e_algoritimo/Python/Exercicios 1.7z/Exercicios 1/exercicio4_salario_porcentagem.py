
#-*- coding: UTF-8 -*-

print("me diga seu salario e a porcentagem do aumento dele, que eu lhe direi qual seu salario atual")
num1= float(input("digite seu salário: "))
num2= float(input("digite a porcentagem: "))
salario= (num1 * num2) /100
print("o seu salario atual é: ",salario)
