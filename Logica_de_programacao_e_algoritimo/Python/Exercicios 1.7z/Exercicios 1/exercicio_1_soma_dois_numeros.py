#-*- coding: UTF-8 -*-

print("Olá usuário. Eu vou fazer a soma de dois numeros inteiros para você")
num1= int(input("Digite o primeiro valor: "))
num2= int(input("Digite o segundo valor: "))
soma= num1 + num2
print("o valor da sua soma é de: ", soma)
