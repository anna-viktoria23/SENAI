
#-*- coding: UTF-8 -*-
print("Olá usuário. eu vou fazer sua conversão de metros para milimetros")
num1= float(input("digite o valor em metros: "))
milimetros= num1 * 1000
print("o valor convertido em milimetros é de: ",milimetros)
